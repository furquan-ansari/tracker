import { useEffect, useState } from 'react';
import './App.css';
import axios from 'axios';
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Dashboard from './Components/Dashboard/Dashboard';
import Navbar from './Components/Navbar/Navbar';
import Login from './Components/Login/Login';
import ProjectPage from './Components/Dashboard/Supervisor/ProjectPage/ProjectPage';

function App() {

  const [loggedIn, setLoggedIn] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isProduction, setIsProduction] = useState(false);
  const [userName, setUserName] = useState(false);

  useEffect(() => {
    const isAuthenticated = localStorage.getItem('loggedIn');
    if (isAuthenticated === 'true') {
      setLoggedIn(true);
      const isAdminUser = localStorage.getItem('isAdmin');
      setIsAdmin(isAdminUser === 'true');
      const isProductionUser = localStorage.getItem('isProduction');
      setIsProduction(isProductionUser === 'true');
      const storedUserName = localStorage.getItem('userName');
      if (storedUserName) {
        setUserName(storedUserName);
      }
    }
  }, []);

  const handleLogin = async (username, password) => {
    try {
      const loginUrl = 'http://localhost:3001/api/login';

      const response = await axios.post(loginUrl, { username, password });
      const { user, role } = response.data;

      localStorage.setItem('userName', `${user.firstName} ${user.lastName}`);

      setUserName(user);

      if (role === 'admin') {
        setIsAdmin(true);
        localStorage.setItem('isAdmin', 'true');
      } else if (role === 'Production') {
        setIsProduction(true);
        localStorage.setItem('isProduction', 'true');
      }
      localStorage.setItem('loggedIn', 'true');
      localStorage.setItem('userName', user)
      setLoggedIn(true);
    } catch (error) {
      console.error('Login error:', error);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('loggedIn');
    localStorage.removeItem('isAdmin');
    localStorage.removeItem('isProduction');
    setLoggedIn(false);
    setIsAdmin(false);
    setIsProduction(false);
  };

  return (
    <div>
      <Router>
        {!loggedIn && (
          <>
            <Routes>
              <Route path="/" element={<Login handleLogin={handleLogin} />} />
            </Routes>
          </>
        )}
        {loggedIn && (
          <>
            <Navbar title="Tracker" loggedIn={loggedIn} isProduction={isProduction} isAdmin={isAdmin} userName={userName} handleLogout={handleLogout} />
            <div className="container-fluid">
              <Routes>
                <Route exact path="/" element={<Dashboard userName={userName} isProduction={isProduction} isAdmin={isAdmin} />} />
                <Route exact Path="/ProjectPage/:projectName" element={<ProjectPage />} />
              </Routes>
            </div>
          </>
        )}
      </Router>
    </div>
  );
}

export default App;
