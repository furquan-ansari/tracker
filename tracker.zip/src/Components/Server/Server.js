const express = require('express');
const mysql = require('mysql');
const app = express();
const cors = require('cors');

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'tracker'
});

connection.connect((err) => {
    if (err) throw err;
    console.log('Connected to MySQL database!');
});

app.use(express.json());

app.use(cors());


// app.post('/api/insert-data', (req, res) => {
//     const { projectName, description, startDate, endDate, departments } = req.body;

//     const query = 'INSERT INTO tbl_NewProject (P_name, P_description, P_startDate, P_endDate, P_departments) VALUES (?, ?, ?, ?, ?)';
//     connection.query(query, [projectName, description, startDate, endDate, JSON.stringify(departments)], (err, result) => {
//         if (err) {
//             console.error('Error inserting data:', err);
//             res.status(500).json({ message: 'Error inserting data' });
//         } else {
//             console.log('Data inserted successfully');
//             res.json({ message: 'Data inserted successfully' });
//         }
//     });
// });

app.post('/api/new-project', (req, res) => {
    const { projectName, description, startDate, departments } = req.body;

    const departmentValues = departments.map(department => department.value);
    const departmentsString = departmentValues.join(', ');

    const query = 'INSERT INTO tbl_NewProject (P_name, P_description, P_startDate, P_departments) VALUES (?, ?, ?, ?)';
    connection.query(query, [projectName, description, startDate, departmentsString], (err, result) => {
        if (err) {
            console.error('Error inserting data:', err);
            res.status(500).json({ message: 'Error inserting data' });
        } else {
            console.log('Data inserted successfully');
            // Get the inserted project's ID
            const insertedId = result.insertId;
            // Retrieve the inserted project from the database
            connection.query('SELECT * FROM tbl_NewProject WHERE P_id = ?', [insertedId], (err, rows) => {
                if (err) {
                    console.error('Error retrieving inserted data:', err);
                    res.status(500).json({ message: 'Error retrieving inserted data' });
                } else {
                    const insertedProject = rows[0];
                    res.json(insertedProject);
                }
            });
        }
    });
});


// Add a new endpoint to fetch data
app.get('/api/select-projects', (req, res) => {
    const query = 'SELECT * FROM tbl_NewProject';
    connection.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching data:', err);
            res.status(500).json({ message: 'Error fetching data' });
        } else {
            res.json(results);
        }
    });
});


app.post('/api/login', (req, res) => {
    const { username, password } = req.body;

    const query = 'SELECT * FROM tracker_login WHERE username = ? AND password = ?';
    connection.query(query, [username, password], (err, results) => {
        if (err) {
            console.error('Error executing query:', err);
            res.status(500).json({ message: 'Internal server error' });
            return;
        }

        if (results.length > 0) {
            const { role, firstName, lastName } = results[0];
            res.json({ user: { firstName, lastName }, role });
        } else {
            res.status(401).json({ message: 'Invalid credentials' });
        }
    });
});

app.listen(3001, () => {
    console.log('Server started on port 3001');
});