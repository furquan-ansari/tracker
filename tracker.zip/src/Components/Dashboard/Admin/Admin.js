import React from 'react'

export default function Admin(props) {
  return (
    <div>
      <h1>{props.userFirstName} {props.userLastName}</h1>
    </div>
  )
}
