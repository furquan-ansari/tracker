import React from 'react'

export default function ProjectPage() {
  return (
    <div>
      <h1>MD is Great</h1>
    </div>
  )
}
