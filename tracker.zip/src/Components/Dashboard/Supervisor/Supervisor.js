import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { FaAngleRight, FaPlus } from "react-icons/fa";
import Select from 'react-select';
import { useNavigate } from 'react-router-dom';

const options = [
    { value: 'Match Move', label: 'Match Move' },
    { value: 'Layout', label: 'Layout' },
    { value: 'ROTO', label: 'ROTO' },
    { value: 'Clean-up', label: 'Clean-up' },
    { value: 'Matte-paint', label: 'Matte-paint' },
    { value: 'Motion Graphics', label: 'Motion Graphics' },
    { value: 'FX', label: 'FX' },
    { value: 'Lightining', label: 'Lightining' },
    { value: 'Render', label: 'Render' },
    { value: 'Compositing', label: 'Compositing' }
];
export default function Supervisor() {

    const [formData, setFormData] = useState({
        projectName: '',
        description: '',
        start_date: '',
        // end_date: '',
        departments: []
    });

    const handleChange = (selectedOptions) => {
        setFormData({ ...formData, departments: selectedOptions });
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        const { projectName, description, start_date, departments } = formData;
        axios.post('http://localhost:3001/api/new-project', { projectName, description, startDate: start_date, departments })
            .then(response => {
                // props.showAlert("success", "Data inserted successfully!");

                // <Alert type="success" message="Data inserted successfully" />
                console.log('Data inserted successfully:', response.data);
                // Add the newly inserted project to the projects array
                setProjects([...projects, response.data]);
                // Reset form data
                setFormData({
                    projectName: '',
                    description: '',
                    start_date: '',
                    departments: []
                });

            })
            .catch(error => {
                console.error('Error inserting data:', error);
            });
    };



    const handleInputChange = (event) => {
        const { name, value } = event.target;
        setFormData({ ...formData, [name]: value });
    };


    // select from database
    const [projects, setProjects] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        fetchProjects();
    }, []);

    const fetchProjects = () => {
        axios.get('http://localhost:3001/api/select-projects')
            .then(response => {
                setProjects(response.data);
            })
            .catch(error => {
                console.error('Error fetching data:', error);
            });
    };

    //Navigate Project Page
    const navigateToProjectDetails = (projectId) => {
        // navigate(`/ProjectPage/${projectId}`);
        const projectName = getProjectNameById(projectId);
        navigate(`/ProjectPage/${encodeURIComponent(projectName)}`);

    };

    const getProjectNameById = (projectId) => {
        const project = projects.find(project => project.P_id === projectId);
        return project ? project.P_name : '';
    };

    return (
        <>
            <div className='container'>
                {/* {props.userFirstName} {props.userLastName} */}
                <div className="table-responsive">
                    <table className='table table-striped' style={{ width: '100%' }}>
                        <thead>
                            <tr>
                                <th colSpan={5} style={{ textAlign: 'right' }}>
                                    <button className='btn btn-secondary' data-bs-toggle="modal" data-bs-target="#CreateNewProject"><FaPlus /> New Project</button>
                                </th>
                            </tr>
                            <tr style={{ textAlign: 'center', fontWeight: 'bold', backgroundColor: 'gray' }}>
                                <td width={'20%'}>
                                    Project Name
                                </td>
                                <td width={'25%'}>
                                    Description
                                </td>
                                <td width={'10%'}>
                                    Start Date
                                </td>
                                {/* <td width={'10%'}>
                                End Date
                            </td> */}
                                <td width={'35%'}>
                                    Departments
                                </td>
                            </tr>
                        </thead>
                        <tbody className="table-group-divider">
                            {projects.map((project) => (
                                <tr key={project.P_id}>
                                    <td>{project.P_name}</td>
                                    <td>{project.P_description}</td>
                                    <td>{project.P_startDate}</td>
                                    {/* <td>{project.P_endDate}</td> */}
                                    <td>{project.P_departments}</td>
                                    <td>
                                        <button className='btn btn-small' onClick={() => navigateToProjectDetails(project.P_id)}> <FaAngleRight /> </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>



            {/* Insert New Project Code - Modal */}

            <div className="modal fade" id="CreateNewProject" tabIndex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div className="modal-dialog modal-lg">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h1 className="modal-title fs-5" id="exampleModalLabel">Create New Project</h1>
                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <form onSubmit={handleSubmit}>
                            <div className="modal-body">
                                <div className="row">
                                    <div className="col">
                                        <span>Project Name</span>
                                        <input type="text" placeholder="Project Name" className="form-control mt-1" id="projectName" name="projectName" value={formData.projectName} onChange={handleInputChange} required />
                                    </div>
                                    <div className="col">
                                        <span>Description</span>
                                        <input type="text" placeholder="Description" className="form-control mt-1" id="description" name="description" value={formData.description} onChange={handleInputChange} required />
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col">
                                        <span>Start Date</span>
                                        <input type="date" className="form-control mt-1" id="start_date" name="start_date" value={formData.start_date} onChange={handleInputChange} required />
                                    </div>
                                    <div className="col">
                                        <span>Departments involve</span>
                                        <Select options={options} isMulti onChange={handleChange} placeholder="Department Involves..." closeMenuOnSelect={false} required />
                                    </div>
                                </div>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-white border" data-bs-dismiss="modal">Close</button>
                                <button type="submit" className="btn btn-success">Save changes</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </>
    )
}
