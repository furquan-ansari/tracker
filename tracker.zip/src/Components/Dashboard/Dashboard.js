import React, { useEffect, useState } from 'react';
import Admin from './Admin/Admin.js';
import Supervisor from './Supervisor/Supervisor.js'

export default function Dashboard(props) {

    const [userFirstName, setUserFirstName] = useState('');
    const [userLastName, setUserLastName] = useState('');

    useEffect(() => {
        if (props.userName) {
            setUserFirstName(props.userName.firstName);
            setUserLastName(props.userName.lastName);
        }
    }, [props.userName]);


    return (
        <>
            {props.isAdmin && (
                <Admin userFirstName={userFirstName} userLastName={userLastName} />
            )}

            {props.isProduction && (
                <Supervisor userFirstName={userFirstName} mode={props.mode} userLastName={userLastName} />
            )}
        </>
    )
}
