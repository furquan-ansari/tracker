import React, { useState } from 'react';
import { FaUserAlt, FaLock } from "react-icons/fa";
import "./Login.css";
import { Link } from 'react-router-dom';

export default function Login(props) {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        props.handleLogin(username, password);
    };

    return (<div className="Auth-form-container">
        <form className="Auth-form" onSubmit={handleSubmit}>
            <div className="Auth-form-content">
                <h3 className="Auth-form-title">Login</h3>
                <div className="form-group ">
                    <FaUserAlt className='icon' />

                    <input type="email" placeholder='Username' className="form-control mt-1" id="username" value={username} onChange={(e) => setUsername(e.target.value)} />
                </div>
                <div className="form-group mt-3">
                    <FaLock className='icon' />
                    <input type="password" placeholder='Password' className="form-control mt-1" id="password" value={password} onChange={(e) => setPassword(e.target.value)} />
                </div>
                <div className="d-grid gap-2 mt-3">
                    <button type="submit" className="button-effect">
                        Login
                    </button>
                </div>
                <p className="FP mt-3">
                    Forgot <Link to="#">password?</Link>
                </p>
            </div>
        </form>
    </div>
    );
}